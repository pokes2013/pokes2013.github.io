# SoftEther centos 服务器搭建及客户端连接

> SoftEther centos 服务器搭建 及 客户端连接，开始安装 1 安装部署服务端 cd/usr/local / 打开要安装的路径，可以自定义 #wgethttps://github.com/SoftEth......#

© 著作权归作者所有：来自 51CTO 博客作者韩馨空的原创作品，如需转载，请与作者联系，否则将追究法律责任

主博客地址`https://blog.csdn.net/hanxinkong`

---

开始安装

---

> 1 安装部署 服务端

cd /usr/local/

---

> 打开要安装的路径，可以自定义

`# wget https:///SoftEther×××/SoftEther×××_Stable/releases/download/v4.28-9669-beta/softether-***server-v4.28-9669-beta-2018.09.11-linux-x64-64bit.tar.gz`

> 下载安装包

`# tar zxvf softether-***server-v4.28-9669-beta-2018.09.11-linux-x64-64bit.tar.gz`

> 解压安装包

cd ***server

---

1

> 进入目录

![](http://i2.51cto.com/images/blog/201810/29/57e714c9f94584a8af58cb95b48fd052.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

`#make` 1

编译安装

---

2 启动服务

---

`./***server start`

> 运行 SoftEther

3 设置密码

---

`#./***cmd`

![](http://i2.51cto.com/images/blog/201810/29/9ed060540247c60aa7f30144739c951c.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 输入 1

![](http://i2.51cto.com/images/blog/201810/29/fc11f94b9e71f632a191697b0b700987.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 5555 为自定义端口

![](http://i2.51cto.com/images/blog/201810/29/3b14240f4612546c0504e4d41ac2b7c5.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 这里默认，回车

![](http://i2.51cto.com/images/blog/201810/29/feddc7780f1673d71a249bd10dbdd3c9.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)``

> 进入控制台界面

ServerPasswordSet

---

![](http://i2.51cto.com/images/blog/201810/29/d3c735153477625e0008ffc8f772ae52.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 设置用于 windows 客户端 管理服务端的登录密码

4 softether 管理端

---

> 下载地址 https://www.softether-download.com/cn.aspx?product=softether

![](http://i2.51cto.com/images/blog/201810/29/5bceda52b96efad5f1d80396c6468d09.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 下载管理端

![](http://i2.51cto.com/images/blog/201810/29/7a97f6a28f44fda3ad45c168279c2cc9.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 安装完成后 打开软件

![](http://i2.51cto.com/images/blog/201810/29/71b9aec553bf584d6cacf660917e7240.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 新设置

![](http://i2.51cto.com/images/blog/201810/29/a38a30e96f618ccd2e28478f3887a536.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

填写相应信息

![](http://i2.51cto.com/images/blog/201810/29/667bca8eecd10330b41426bd64e5c451.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 连接

![](http://i2.51cto.com/images/blog/201810/29/b9f0c80e3c2037217a60698ef296b68b.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 编辑服务器

![](http://i2.51cto.com/images/blog/201810/29/42582cea4fe462bb80827ac417b680b6.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

![](http://i2.51cto.com/images/blog/201810/29/e588cb249088db075475518d84173581.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 添加用户

![](http://i2.51cto.com/images/blog/201810/29/b079833342ed7623a333525f6e27bfab.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 配置 NAT 和 DHCP

![](http://i2.51cto.com/images/blog/201810/29/f19588343ba52b5e505a8a09cc14a8f0.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

![](http://i2.51cto.com/images/blog/201810/29/03f6a68d76fb64f05747ebcd49b0405c.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

![](http://i2.51cto.com/images/blog/201810/29/9f432ca15515756b1f4b625e746dcbe3.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

![](http://i2.51cto.com/images/blog/201810/29/056211b54d7a467cf03241ef8301a755.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 产生配置文件 ，open*** 可直接调用

![](http://i2.51cto.com/images/blog/201810/29/2d2da5c264b127a0a5127e502d40b66a.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

![](http://i2.51cto.com/images/blog/201810/29/c533dced13fa7fa1d85756f8ef0aa231.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 到此管理端配置好了

5 windows 客户端的使用

---

> 下载客户端 https://www.softether-download.com/cn.aspx?product=softether

![](http://i2.51cto.com/images/blog/201810/29/c78bbb38a3448a598c05eb57f1ae7e18.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 安装完成后打开

![](http://i2.51cto.com/images/blog/201810/29/431d73b486898b4d938102e1be9b6d3d.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 填入服务端 的配置

![](http://i2.51cto.com/images/blog/201810/29/c7a6bb73a33c9795edf1e9205c063fb6.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 双击 连接

![](http://i2.51cto.com/images/blog/201810/29/d322d2b5fd55cedf09de157172a3a385.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> linux 客户端的使用

---

> 安装客户端

`https://www.softether-download.com/cn.aspx?product=softether`

> 进入用户目录

cd /usr/local/

---

> 传入远程主机

rz
--

![](http://i2.51cto.com/images/blog/201810/29/907aa4120a7d26dd381f8e4525748cb1.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 解压安装包

`tar zxvf softether-***client-v4.28-9669-beta-2018.09.11-linux-x64-64bit.tar.gz`

> 进入目录

cd ***client

![](http://i2.51cto.com/images/blog/201810/29/8dadaf0706706de6b952dd62349d77ea.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 安装依赖包 gcc， 编译安装

#yum# install -y gcc

#make#

全部选 1

![](http://i2.51cto.com/images/blog/201810/29/d690c1641edbb627924573b9c88b6725.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 启动服务

./***client start

配置客户端

---

`# ./***cmd`

> 选择 2

![](http://i2.51cto.com/images/blog/201810/29/8f55d35eacacb15f9f188aa8c5ab1d93.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 回车 默认 localhost

![](http://i2.51cto.com/images/blog/201810/29/c458e5498e0efb3c25dda10d38a921a9.png?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 允许客户端管理

#RemoteEnable# 1 ![](http://i2.51cto.com/images/blog/201810/29/71858412f68484280f3a1ac23bd2b6cb.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 退出配置，回到控制台

#exit#

> 设置路由 ip route add 远程服务器 ip via 本地默认网关 dev eth0

> 删除默认路由

ip route del default
1

> 添加路由

ip route add default via 远程服务器网关

![](http://i2.51cto.com/images/blog/201810/29/e218679c6d96418c312a9f0c0382c91e.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 检测连接

ping 8.8.8.8 ![](http://i2.51cto.com/images/blog/201810/29/5a8a009049ffa1180c689c71bdc72677.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

windows 客户管理端

---

> 输入 远程 linux 主机 ip

![](http://i2.51cto.com/images/blog/201810/29/2d29f98de8bcaf8a13340dbf0f24b747.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 建立连接

![](http://i2.51cto.com/images/blog/201810/29/f801b6979c56a10d2b44b5db0b0c0173.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

> 双击连接 如果没响应 f5 刷新

> ip 变为远程 *** 服务器 IP

![](http://i2.51cto.com/images/blog/201810/29/3eeec2f56a12c69c708f94bdaabeebd4.jpg?x-oss-process=image/watermark,size_16,text_QDUxQ1RP5Y2a5a6i,color_FFFFFF,t_30,g_se,x_10,y_10,shadow_20,type_ZmFuZ3poZW5naGVpdGk=)

特殊情况

---

> 如果 *** 连接没有 ip

> DHCP 自动获取 ip

#dhclient#

> 此时配置连接完成了
